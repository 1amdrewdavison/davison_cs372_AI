//Written by Andrew Davison for Project A3 for CSC 372: Artificial Intelligence with Dr. Thomas Allen
//Implements the simple hill climbing method for solving SAT
//Implements the function simpleHillClimbing in SAT.hpp

